<?php
/**
 * Domain rules kept independent of WordPress for quick, meaningful tests.
 */

defined( 'ABSPATH' ) || exit;

final class Intake_Desk_Domain {
    public const STAGES = array(
        'new'         => 'New enquiry',
        'waiting'     => 'Waiting for information',
        'ready'       => 'Ready for work',
        'in_progress' => 'In progress',
        'done'        => 'Completed',
    );

    public static function valid_stage( string $stage ): bool {
        return isset( self::STAGES[ $stage ] );
    }

    /**
     * Keep fields small and explicit. We do not accept identity documents,
     * tax records or other sensitive attachments in this prototype.
     */
    public static function validate_enquiry( array $data ): array {
        $errors = array();
        $name = trim( (string) ( $data['name'] ?? '' ) );
        $email = trim( (string) ( $data['email'] ?? '' ) );
        $service = trim( (string) ( $data['service'] ?? '' ) );
        $summary = trim( (string) ( $data['summary'] ?? '' ) );

        if ( '' === $name || self::length( $name ) > 100 ) {
            $errors[] = 'Name is required and must be at most 100 characters.';
        }
        if ( ! filter_var( $email, FILTER_VALIDATE_EMAIL ) || self::length( $email ) > 254 ) {
            $errors[] = 'Enter a valid email address.';
        }
        if ( '' === $service || self::length( $service ) > 80 ) {
            $errors[] = 'Service is required and must be at most 80 characters.';
        }
        if ( '' === $summary || self::length( $summary ) > 2000 ) {
            $errors[] = 'A short description is required (up to 2000 characters).';
        }
        return $errors;
    }

    public static function valid_due_date( string $date ): bool {
        if ( '' === $date ) {
            return true;
        }
        $parsed = DateTimeImmutable::createFromFormat( '!Y-m-d', $date );
        return $parsed && $parsed->format( 'Y-m-d' ) === $date;
    }

    public static function safe_csv_cell( string $text ): string {
        $text = str_replace( array( "\r", "\n" ), ' ', $text );
        return preg_match( '/^[\s]*[=+@\-\t]/u', $text ) ? "'" . $text : $text;
    }

    private static function length( string $value ): int {
        return function_exists( 'mb_strlen' ) ? mb_strlen( $value ) : strlen( $value );
    }
}
