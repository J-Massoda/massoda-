<?php

defined( 'ABSPATH' ) || exit;

final class Intake_Desk {
    private const POST_TYPE = 'intake_request';
    private const META = '_intake_desk_';

    public static function activate(): void {
        self::register_post_type();
        flush_rewrite_rules();
    }

    public static function init(): void {
        add_action( 'init', array( __CLASS__, 'register_post_type' ) );
        add_shortcode( 'intake_desk_form', array( __CLASS__, 'form' ) );
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_form_style' ) );
        add_action( 'admin_post_nopriv_intake_desk_submit', array( __CLASS__, 'submit' ) );
        add_action( 'admin_post_intake_desk_submit', array( __CLASS__, 'submit' ) );
        add_action( 'admin_post_intake_desk_update', array( __CLASS__, 'update' ) );
        add_action( 'admin_post_intake_desk_delete', array( __CLASS__, 'delete' ) );
        add_action( 'admin_post_intake_desk_export', array( __CLASS__, 'export_csv' ) );
        add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
    }

    public static function register_post_type(): void {
        register_post_type(
            self::POST_TYPE,
            array(
                'label'               => 'Intake requests',
                'public'              => false,
                'publicly_queryable'  => false,
                'exclude_from_search' => true,
                'show_ui'             => false,
                'show_in_rest'        => false,
                'supports'            => array( 'title' ),
                'rewrite'             => false,
                'query_var'           => false,
            )
        );
    }

    private static function input( string $name ): string {
        $value = $_POST[ $name ] ?? '';
        return is_string( $value ) ? wp_unslash( $value ) : '';
    }

    private static function meta( int $id, string $name ): string {
        return (string) get_post_meta( $id, self::META . $name, true );
    }

    private static function redirect_url( string $result ): string {
        $fallback = home_url( '/' );
        $requested = self::input( 'return_url' );
        $base = wp_validate_redirect( $requested, $fallback );
        return add_query_arg( 'intake_result', $result, remove_query_arg( 'intake_result', $base ) );
    }

    public static function enqueue_form_style(): void {
        if ( is_singular() ) {
            $post = get_post();
            if ( $post && has_shortcode( $post->post_content, 'intake_desk_form' ) ) {
                wp_enqueue_style( 'intake-desk-form', plugins_url( 'assets/form.css', INTAKE_DESK_PATH . 'intake-desk.php' ), array(), INTAKE_DESK_VERSION );
            }
        }
    }

    public static function form(): string {
        $result = isset( $_GET['intake_result'] ) && is_string( $_GET['intake_result'] )
            ? sanitize_key( wp_unslash( $_GET['intake_result'] ) ) : '';
        $messages = array(
            'received' => 'Thank you. Your enquiry has been received. We will contact you about the next step.',
            'invalid'  => 'Please complete all fields with a valid email address.',
            'limited'  => 'Too many requests were sent recently. Please try again later.',
            'error'    => 'We could not save your enquiry. Please try again later.',
        );
        ob_start();
        ?>
        <div class="intake-desk-form">
            <?php if ( isset( $messages[ $result ] ) ) : ?>
                <p role="status" class="intake-desk-message"><?php echo esc_html( $messages[ $result ] ); ?></p>
            <?php endif; ?>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="intake_desk_submit">
                <input type="hidden" name="return_url" value="<?php echo esc_url( get_permalink() ?: home_url( '/' ) ); ?>">
                <?php wp_nonce_field( 'intake_desk_submit', 'intake_desk_nonce' ); ?>
                <p class="intake-desk-trap" aria-hidden="true"><label>Leave this field empty <input type="text" name="company_website" tabindex="-1" autocomplete="off"></label></p>
                <p><label for="intake-name">Your name</label><br><input id="intake-name" name="name" type="text" maxlength="100" required autocomplete="name"></p>
                <p><label for="intake-email">Email</label><br><input id="intake-email" name="email" type="email" maxlength="254" required autocomplete="email"></p>
                <p><label for="intake-service">What service do you need?</label><br><input id="intake-service" name="service" type="text" maxlength="80" required></p>
                <p><label for="intake-summary">Tell us what you need help with</label><br><textarea id="intake-summary" name="summary" maxlength="2000" rows="5" required></textarea></p>
                <p class="intake-desk-note">Please do not include identity documents, tax records, passwords or payment details. This form does not accept files.</p>
                <p><button type="submit">Send enquiry</button></p>
            </form>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    public static function submit(): void {
        if ( ! isset( $_POST['intake_desk_nonce'] ) || ! is_string( $_POST['intake_desk_nonce'] ) ||
            ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['intake_desk_nonce'] ) ), 'intake_desk_submit' ) ) {
            wp_die( 'Invalid request.', '', array( 'response' => 403 ) );
        }
        if ( '' !== self::input( 'company_website' ) ) {
            wp_safe_redirect( self::redirect_url( 'received' ), 303 );
            exit;
        }
        $data = array(
            'name'    => sanitize_text_field( self::input( 'name' ) ),
            'email'   => sanitize_email( self::input( 'email' ) ),
            'service' => sanitize_text_field( self::input( 'service' ) ),
            'summary' => sanitize_textarea_field( self::input( 'summary' ) ),
        );
        if ( Intake_Desk_Domain::validate_enquiry( $data ) ) {
            wp_safe_redirect( self::redirect_url( 'invalid' ), 303 );
            exit;
        }
        $ip = isset( $_SERVER['REMOTE_ADDR'] ) && is_string( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : 'unknown';
        $rate_key = 'intake_desk_rate_' . hash_hmac( 'sha256', $ip, wp_salt() );
        $count = (int) get_transient( $rate_key );
        if ( $count >= 5 ) {
            wp_safe_redirect( self::redirect_url( 'limited' ), 303 );
            exit;
        }
        $id = self::create_request( $data );
        if ( is_wp_error( $id ) ) {
            wp_safe_redirect( self::redirect_url( 'error' ), 303 );
            exit;
        }
        set_transient( $rate_key, $count + 1, HOUR_IN_SECONDS );
        wp_mail( get_option( 'admin_email' ), 'New IntakeDesk enquiry #' . $id,
            'A new enquiry is ready for review: ' . admin_url( 'admin.php?page=intake-desk&request_id=' . $id ) );
        wp_safe_redirect( self::redirect_url( 'received' ), 303 );
        exit;
    }

    /** @return int|WP_Error */
    public static function create_request( array $data ) {
        if ( Intake_Desk_Domain::validate_enquiry( $data ) ) {
            return new WP_Error( 'intake_invalid', 'Invalid enquiry.' );
        }
        $id = wp_insert_post(
            array(
                'post_type'   => self::POST_TYPE,
                'post_status' => 'private',
                'post_title'  => 'Intake request',
                'meta_input'  => array(
                    self::META . 'name'        => $data['name'],
                    self::META . 'email'       => $data['email'],
                    self::META . 'service'     => $data['service'],
                    self::META . 'summary'     => $data['summary'],
                    self::META . 'stage'       => 'new',
                    self::META . 'next_action' => 'Review the enquiry',
                    self::META . 'missing'     => '',
                    self::META . 'due_date'    => '',
                    self::META . 'history'     => array(
                        array( 'time' => gmdate( 'c' ), 'actor' => 0, 'stage' => 'new', 'note' => 'Enquiry received.' ),
                    ),
                ),
            ),
            true
        );
        return $id;
    }

    public static function menu(): void {
        add_menu_page( 'IntakeDesk', 'IntakeDesk', 'manage_options', 'intake-desk', array( __CLASS__, 'admin_page' ), 'dashicons-clipboard', 26 );
    }

    private static function request( int $id ): ?WP_Post {
        $post = get_post( $id );
        return $post && self::POST_TYPE === $post->post_type && 'private' === $post->post_status ? $post : null;
    }

    public static function admin_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Permission denied.', '', array( 'response' => 403 ) );
        }
        $id = isset( $_GET['request_id'] ) ? absint( $_GET['request_id'] ) : 0;
        echo '<div class="wrap intake-desk-admin"><h1>IntakeDesk</h1>';
        if ( $id ) {
            self::render_detail( $id );
        } else {
            self::render_list();
        }
        echo '</div>';
    }

    private static function render_list(): void {
        $stage = isset( $_GET['stage'] ) && is_string( $_GET['stage'] ) ? sanitize_key( wp_unslash( $_GET['stage'] ) ) : '';
        if ( ! Intake_Desk_Domain::valid_stage( $stage ) ) { $stage = ''; }
        $page = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
        $query = new WP_Query(
            array(
                'post_type'      => self::POST_TYPE,
                'post_status'    => 'private',
                'posts_per_page' => 20,
                'paged'          => $page,
                'orderby'        => 'date',
                'order'          => 'DESC',
                'meta_query'     => $stage ? array( array( 'key' => self::META . 'stage', 'value' => $stage ) ) : array(),
            )
        );
        echo '<p>Track what each client needs, who should act next and what is ready for work.</p>';
        echo '<p><a class="button" href="' . esc_url( admin_url( 'admin.php?page=intake-desk' ) ) . '">All</a> ';
        foreach ( Intake_Desk_Domain::STAGES as $value => $label ) {
            echo '<a class="button" href="' . esc_url( add_query_arg( array( 'page' => 'intake-desk', 'stage' => $value ), admin_url( 'admin.php' ) ) ) . '">' . esc_html( $label ) . '</a> ';
        }
        echo '</p><p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=intake_desk_export' ), 'intake_desk_export' ) ) . '">Export CSV</a></p>';
        echo '<table class="widefat striped"><thead><tr><th>Reference</th><th>Contact</th><th>Service</th><th>Stage</th><th>Next action</th><th>Due</th><th>Received</th></tr></thead><tbody>';
        foreach ( $query->posts as $post ) {
            $link = add_query_arg( array( 'page' => 'intake-desk', 'request_id' => $post->ID ), admin_url( 'admin.php' ) );
            echo '<tr><td><a href="' . esc_url( $link ) . '">#' . esc_html( (string) $post->ID ) . '</a></td>';
            echo '<td>' . esc_html( self::meta( $post->ID, 'name' ) ) . '<br><small>' . esc_html( self::meta( $post->ID, 'email' ) ) . '</small></td>';
            echo '<td>' . esc_html( self::meta( $post->ID, 'service' ) ) . '</td>';
            $current = self::meta( $post->ID, 'stage' );
            echo '<td>' . esc_html( Intake_Desk_Domain::STAGES[ $current ] ?? $current ) . '</td>';
            echo '<td>' . esc_html( self::meta( $post->ID, 'next_action' ) ) . '</td>';
            echo '<td>' . esc_html( self::meta( $post->ID, 'due_date' ) ) . '</td>';
            echo '<td>' . esc_html( get_the_date( 'Y-m-d H:i', $post ) ) . '</td></tr>';
        }
        if ( ! $query->have_posts() ) { echo '<tr><td colspan="7">No requests in this view.</td></tr>'; }
        echo '</tbody></table>';
        if ( $query->max_num_pages > 1 ) {
            echo '<p>' . wp_kses_post( paginate_links( array(
                'base' => add_query_arg( 'paged', '%#%' ), 'current' => $page,
                'total' => $query->max_num_pages,
            ) ) ) . '</p>';
        }
        wp_reset_postdata();
    }

    private static function render_detail( int $id ): void {
        if ( ! self::request( $id ) ) {
            echo '<p>Request not found.</p>';
            return;
        }
        $back = admin_url( 'admin.php?page=intake-desk' );
        echo '<p><a href="' . esc_url( $back ) . '">&larr; All requests</a></p><h2>Request #' . esc_html( (string) $id ) . '</h2>';
        echo '<div class="intake-desk-detail"><p><strong>Contact:</strong> ' . esc_html( self::meta( $id, 'name' ) ) . ' &lt;' . esc_html( self::meta( $id, 'email' ) ) . '&gt;</p>';
        echo '<p><strong>Service:</strong> ' . esc_html( self::meta( $id, 'service' ) ) . '</p>';
        echo '<p><strong>Enquiry:</strong><br>' . nl2br( esc_html( self::meta( $id, 'summary' ) ) ) . '</p></div>';
        echo '<h2>Update the workflow</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="intake_desk_update"><input type="hidden" name="request_id" value="' . esc_attr( (string) $id ) . '">';
        wp_nonce_field( 'intake_desk_update_' . $id );
        echo '<table class="form-table"><tr><th><label for="intake-stage">Stage</label></th><td><select id="intake-stage" name="stage">';
        foreach ( Intake_Desk_Domain::STAGES as $value => $label ) {
            echo '<option value="' . esc_attr( $value ) . '" ' . selected( self::meta( $id, 'stage' ), $value, false ) . '>' . esc_html( $label ) . '</option>';
        }
        echo '</select></td></tr>';
        self::text_row( 'Next action', 'next_action', self::meta( $id, 'next_action' ), 500 );
        self::textarea_row( 'Missing information', 'missing', self::meta( $id, 'missing' ), 1000 );
        echo '<tr><th><label for="intake-due">Follow-up date</label></th><td><input id="intake-due" type="date" name="due_date" value="' . esc_attr( self::meta( $id, 'due_date' ) ) . '"></td></tr>';
        self::textarea_row( 'Internal note (optional)', 'note', '', 1000 );
        echo '</table><p><button class="button button-primary" type="submit">Save changes</button></p></form>';
        echo '<h2>Activity</h2><ol class="intake-desk-history">';
        $history = get_post_meta( $id, self::META . 'history', true );
        foreach ( array_reverse( is_array( $history ) ? $history : array() ) as $entry ) {
            if ( ! is_array( $entry ) ) { continue; }
            $actor = ! empty( $entry['actor'] ) ? get_userdata( absint( $entry['actor'] ) ) : null;
            echo '<li><strong>' . esc_html( (string) ( $entry['time'] ?? '' ) ) . '</strong> · ' . esc_html( $actor ? $actor->display_name : 'IntakeDesk' );
            echo ' · ' . esc_html( Intake_Desk_Domain::STAGES[ $entry['stage'] ?? '' ] ?? '' );
            if ( ! empty( $entry['note'] ) ) { echo '<br>' . nl2br( esc_html( (string) $entry['note'] ) ); }
            echo '</li>';
        }
        echo '</ol><hr><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'Permanently delete this request and its personal data?\')">';
        echo '<input type="hidden" name="action" value="intake_desk_delete"><input type="hidden" name="request_id" value="' . esc_attr( (string) $id ) . '">';
        wp_nonce_field( 'intake_desk_delete_' . $id );
        echo '<button class="button" type="submit">Delete request permanently</button></form>';
    }

    private static function text_row( string $label, string $name, string $value, int $max ): void {
        echo '<tr><th><label for="intake-' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label></th><td>';
        echo '<input class="regular-text" id="intake-' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" maxlength="' . esc_attr( (string) $max ) . '" value="' . esc_attr( $value ) . '"></td></tr>';
    }

    private static function textarea_row( string $label, string $name, string $value, int $max ): void {
        echo '<tr><th><label for="intake-' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label></th><td>';
        echo '<textarea class="large-text" rows="4" id="intake-' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" maxlength="' . esc_attr( (string) $max ) . '">' . esc_textarea( $value ) . '</textarea></td></tr>';
    }

    public static function update(): void {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Permission denied.', '', array( 'response' => 403 ) ); }
        $id = absint( self::input( 'request_id' ) );
        if ( ! self::request( $id ) ) { wp_die( 'Request not found.', '', array( 'response' => 404 ) ); }
        check_admin_referer( 'intake_desk_update_' . $id );
        $stage = sanitize_key( self::input( 'stage' ) );
        $next = sanitize_text_field( self::input( 'next_action' ) );
        $missing = sanitize_textarea_field( self::input( 'missing' ) );
        $due = self::input( 'due_date' );
        $note = sanitize_textarea_field( self::input( 'note' ) );
        if ( ! Intake_Desk_Domain::valid_stage( $stage ) || strlen( $next ) > 500 || strlen( $missing ) > 1000 ||
            strlen( $note ) > 1000 || ! Intake_Desk_Domain::valid_due_date( $due ) ) {
            wp_die( 'Invalid workflow fields.', '', array( 'response' => 400 ) );
        }
        self::save_workflow( $id, array( 'stage' => $stage, 'next_action' => $next, 'missing' => $missing,
            'due_date' => $due, 'note' => $note ), get_current_user_id() );
        wp_safe_redirect( admin_url( 'admin.php?page=intake-desk&request_id=' . $id . '&updated=1' ), 303 );
        exit;
    }

    /**
     * Save the reviewed workflow and an attributable activity entry. The
     * admin-post handler owns permission and nonce verification.
     */
    public static function save_workflow( int $id, array $fields, int $actor ): void {
        $old = self::meta( $id, 'stage' );
        $stage = $fields['stage'];
        $next = $fields['next_action'];
        $missing = $fields['missing'];
        $due = $fields['due_date'];
        $note = $fields['note'];
        update_post_meta( $id, self::META . 'stage', $stage );
        update_post_meta( $id, self::META . 'next_action', $next );
        update_post_meta( $id, self::META . 'missing', $missing );
        update_post_meta( $id, self::META . 'due_date', $due );
        $history = get_post_meta( $id, self::META . 'history', true );
        $history = is_array( $history ) ? $history : array();
        $history[] = array(
            'time'  => gmdate( 'c' ), 'actor' => $actor,
            'stage' => $stage, 'note' => $note ?: ( $old === $stage ? 'Workflow details updated.' : 'Stage changed from ' . $old . '.' ),
        );
        update_post_meta( $id, self::META . 'history', array_slice( $history, -50 ) );
    }

    public static function delete(): void {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Permission denied.', '', array( 'response' => 403 ) ); }
        $id = absint( self::input( 'request_id' ) );
        if ( ! self::request( $id ) ) { wp_die( 'Request not found.', '', array( 'response' => 404 ) ); }
        check_admin_referer( 'intake_desk_delete_' . $id );
        wp_delete_post( $id, true );
        wp_safe_redirect( admin_url( 'admin.php?page=intake-desk&deleted=1' ), 303 );
        exit;
    }

    public static function export_csv(): void {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Permission denied.', '', array( 'response' => 403 ) ); }
        check_admin_referer( 'intake_desk_export' );
        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="intake-desk-' . gmdate( 'Y-m-d' ) . '.csv"' );
        $out = fopen( 'php://output', 'w' );
        if ( false === $out ) { exit; }
        fputcsv( $out, array( 'Reference', 'Received', 'Name', 'Email', 'Service', 'Stage', 'Next action', 'Due date' ) );
        $page = 1;
        do {
            $posts = get_posts( array( 'post_type' => self::POST_TYPE, 'post_status' => 'private', 'numberposts' => 100,
                'paged' => $page, 'orderby' => 'ID', 'order' => 'ASC' ) );
            foreach ( $posts as $post ) {
                $values = array( (string) $post->ID, $post->post_date_gmt );
                foreach ( array( 'name', 'email', 'service', 'stage', 'next_action', 'due_date' ) as $field ) {
                    $values[] = Intake_Desk_Domain::safe_csv_cell( self::meta( $post->ID, $field ) );
                }
                fputcsv( $out, $values );
            }
            ++$page;
        } while ( count( $posts ) === 100 );
        fclose( $out );
        exit;
    }
}
