<?php
/**
 * Plugin Name: IntakeDesk
 * Description: A practical client enquiry and intake workflow for WordPress service teams.
 * Version: 1.0.0
 * Requires at least: 6.4
 * Requires PHP: 8.0
 * Author: Jean Emilien Massoda
 * License: GPL-2.0-or-later
 * Text Domain: intake-desk
 */

defined( 'ABSPATH' ) || exit;

define( 'INTAKE_DESK_VERSION', '1.0.0' );
define( 'INTAKE_DESK_PATH', plugin_dir_path( __FILE__ ) );

require_once INTAKE_DESK_PATH . 'includes/class-intake-desk-domain.php';
require_once INTAKE_DESK_PATH . 'includes/class-intake-desk.php';

register_activation_hook( __FILE__, array( 'Intake_Desk', 'activate' ) );
add_action( 'plugins_loaded', array( 'Intake_Desk', 'init' ) );
